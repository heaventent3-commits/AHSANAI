# AHSAN AI — Android voice assistant (Customized by Ahsan)

Original app, not a copy of MAHI AI. No MAHI AI source, server, model or credentials are included.

## Features
- Voice input via Android speech recognition (clear microphone permission flow, graceful errors)
- Spoken replies via Android Text-to-Speech (speed, pitch and on/off in Settings)
- YouTube search by voice or text: `play lofi music`, `youtube cricket highlights`
- Local notes (stored only on the phone): `remember buy milk`, `my notes`, `find note milk`, `clear notes`
- Animated AI orb (idle / listening / speaking states) and a Settings screen
- Basic phone commands (confirmation shown before leaving the app):
  `open camera`, `call 03001234567` (opens dialer, you press call), `flashlight on/off`,
  `set alarm for 7:30 am`, `wifi settings`, `bluetooth settings`, `battery`, `time`, `date`
- Dark blue + cyan theme, custom launcher icon

## Not included
- **No online AI model is connected.** General questions get an honest "not connected" reply.
  To add one later, call your own backend that holds the API key; never put a key in the APK or repo.
- No wake word, no calling by contact name, no toggling Wi-Fi/Bluetooth (Android 10+ blocks this for apps).

## Permissions
`RECORD_AUDIO` (voice input), `SET_ALARM` (alarm requests). Nothing else.

## Build
Versions: AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9, JDK 17, compileSdk/targetSdk 35, minSdk 23.

**GitHub Actions:** push to GitHub → Actions → "Build debug APK" → open the run → download the
`AHSAN-AI-debug-apk` artifact (zip containing `app-debug.apk`).

**Local:** `gradle assembleDebug` (Gradle 8.9+, JDK 17, Android SDK 35) →
`app/build/outputs/apk/debug/app-debug.apk`.

## Install on Realme 7
Unzip the artifact, copy `app-debug.apk` to the phone, open it and allow "install unknown apps" for your file manager.
