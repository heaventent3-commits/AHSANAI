package com.ahsan.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Note(val text: String, val time: Long)

/** Local-only notes stored in this app's private SharedPreferences. */
class NoteStore(context: Context) {
    private val prefs = context.getSharedPreferences("ahsan_ai_memory", Context.MODE_PRIVATE)

    fun all(): List<Note> {
        migrateLegacy()
        val raw = prefs.getString("notes_json", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Note(o.getString("text"), o.optLong("time", 0L))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(text: String) {
        val list = all().toMutableList()
        list.add(Note(text, System.currentTimeMillis()))
        save(list.takeLast(200))
    }

    fun search(query: String): List<Note> = all().filter { it.text.contains(query, ignoreCase = true) }

    fun clear() {
        prefs.edit().remove("notes_json").remove("last_note").apply()
    }

    private fun save(list: List<Note>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("text", it.text).put("time", it.time)) }
        prefs.edit().putString("notes_json", arr.toString()).apply()
    }

    /** The original starter app stored a single "last_note"; keep it. */
    private fun migrateLegacy() {
        val legacy = prefs.getString("last_note", null) ?: return
        if (!prefs.contains("notes_json")) save(listOf(Note(legacy, System.currentTimeMillis())))
        prefs.edit().remove("last_note").apply()
    }
}
