package com.ahsan.ai

import android.content.Context

class AppSettings(context: Context) {
    private val p = context.getSharedPreferences("ahsan_ai_settings", Context.MODE_PRIVATE)

    var speakReplies: Boolean
        get() = p.getBoolean("speak_replies", true)
        set(v) { p.edit().putBoolean("speak_replies", v).apply() }

    var speechRate: Float
        get() = p.getFloat("speech_rate", 1.0f)
        set(v) { p.edit().putFloat("speech_rate", v).apply() }

    var pitch: Float
        get() = p.getFloat("pitch", 1.0f)
        set(v) { p.edit().putFloat("pitch", v).apply() }

    /** True once we have shown the system microphone prompt at least once. */
    var micAsked: Boolean
        get() = p.getBoolean("mic_asked", false)
        set(v) { p.edit().putBoolean("mic_asked", v).apply() }
}
