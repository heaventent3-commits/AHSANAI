package com.ahsan.ai

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.widget.Button
import android.widget.TextView

object Ui {
    val navy = Color.rgb(5, 14, 38)
    val panel = Color.rgb(16, 39, 82)
    val panelLight = Color.rgb(24, 49, 91)
    val cyan = Color.rgb(55, 208, 255)

    fun dp(ctx: Context, v: Int): Int = (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    fun rounded(ctx: Context, fill: Int, radiusDp: Int = 14, strokeColor: Int? = null): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(ctx, radiusDp).toFloat()
            if (strokeColor != null) setStroke(dp(ctx, 1), strokeColor)
        }

    fun button(ctx: Context, label: String, onClick: () -> Unit): Button = Button(ctx).apply {
        text = label
        setAllCaps(false)
        setTextColor(Color.WHITE)
        background = rounded(ctx, Color.rgb(18, 111, 176), 14, cyan)
        setOnClickListener { onClick() }
    }

    fun label(ctx: Context, text: String, sizeSp: Float = 15f, color: Int = Color.WHITE): TextView =
        TextView(ctx).apply {
            this.text = text
            textSize = sizeSp
            setTextColor(color)
        }
}
