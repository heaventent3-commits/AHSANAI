package com.ahsan.ai

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var output: TextView
    private lateinit var input: EditText
    private lateinit var orb: OrbView
    private lateinit var tts: TextToSpeech
    private lateinit var notes: NoteStore
    private lateinit var settings: AppSettings

    private var ttsReady = false
    private var ttsWarned = false
    private var torchOn = false
    private var lastCommand = ""

    private val requestSpeech = 41
    private val requestAudioPermission = 42

    private val ytRegex = Regex(
        "^(?:search\\s+(?:on\\s+)?youtube(?:\\s+for)?|youtube|play)\\s+(.+)$",
        RegexOption.IGNORE_CASE
    )
    private val rememberRegex = Regex(
        "^(?:remember(?:\\s+that)?|save|note|take a note|make a note)\\s+(.+)$",
        RegexOption.IGNORE_CASE
    )
    private val findNoteRegex = Regex(
        "^(?:find|search)\\s+(?:my\\s+)?notes?\\s+(?:for\\s+|about\\s+)?(.+)$",
        RegexOption.IGNORE_CASE
    )
    private val openRegex = Regex("^(?:open|launch|start)\\s+(.+)$", RegexOption.IGNORE_CASE)
    private val callRegex = Regex("^(?:call|dial|phone)\\s+(.+)$", RegexOption.IGNORE_CASE)
    private val alarmRegex = Regex(
        "^(?:set\\s+(?:an?\\s+)?alarm|alarm)\\s*(?:for|at)?\\s*(\\d{1,2})(?:[:\\s.](\\d{2}))?\\s*(am|pm)?$",
        RegexOption.IGNORE_CASE
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = AppSettings(this)
        notes = NoteStore(this)
        buildUi()
        tts = TextToSpeech(this, this)
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi() {
        val frame = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.navy)
            fitsSystemWindows = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(context, 16), Ui.dp(context, 8), Ui.dp(context, 16), Ui.dp(context, 12))
        }
        frame.addView(root, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val title = Ui.label(this, "AHSAN AI", 30f, Ui.cyan).apply {
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        }
        val subtitle = Ui.label(this, "Your personal voice assistant • Customized by Ahsan", 13f, Color.LTGRAY).apply {
            gravity = Gravity.CENTER
        }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(title)
            addView(subtitle)
        }
        val gear = Ui.label(this, "⚙", 26f, Ui.cyan).apply {
            setPadding(Ui.dp(context, 10), Ui.dp(context, 4), Ui.dp(context, 10), Ui.dp(context, 4))
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        }
        val header = FrameLayout(this).apply {
            addView(titleBox, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(gear, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.TOP))
        }

        orb = OrbView(this).apply { setOnClickListener { startSpeech() } }

        output = Ui.label(
            this,
            "Assalamu alaikum! I'm AHSAN AI. Tap the orb or Speak, or type a command. Say \"help\" to see what I can do.",
            17f
        ).apply {
            setPadding(Ui.dp(context, 14), Ui.dp(context, 14), Ui.dp(context, 14), Ui.dp(context, 14))
            background = Ui.rounded(context, Ui.panel, 16)
        }
        val scroll = ScrollView(this).apply { addView(output) }

        input = EditText(this).apply {
            hint = "Type a command..."
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            maxLines = 3
            minHeight = Ui.dp(context, 52)
            setPadding(Ui.dp(context, 14), Ui.dp(context, 8), Ui.dp(context, 14), Ui.dp(context, 8))
            background = Ui.rounded(context, Ui.panelLight, 14, Ui.cyan)
        }

        val send = Ui.button(this, "Send") { handleCommand(input.text.toString()) }
        val speak = Ui.button(this, "🎙 Speak") { startSpeech() }
        val yt = Ui.button(this, "▶ YouTube") { handleYouTubeButton() }
        val save = Ui.button(this, "Save memory") { saveNoteFromInput() }
        val show = Ui.button(this, "My notes") { handleCommand("my notes") }
        val help = Ui.button(this, "Help") { handleCommand("help") }

        root.addView(header)
        root.addView(orb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 190)))
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = Ui.dp(this@MainActivity, 10)
        })
        root.addView(buttonRow(send, speak))
        root.addView(buttonRow(yt, save))
        root.addView(buttonRow(show, help))
        setContentView(frame)
    }

    private fun buttonRow(a: android.view.View, b: android.view.View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        addView(a, weightParams())
        addView(b, weightParams())
    }

    private fun weightParams() = LinearLayout.LayoutParams(0, Ui.dp(this, 50), 1f).apply {
        setMargins(Ui.dp(this@MainActivity, 4), Ui.dp(this@MainActivity, 6), Ui.dp(this@MainActivity, 4), Ui.dp(this@MainActivity, 2))
    }

    private fun handleYouTubeButton() {
        lastCommand = ""
        openYouTube(input.text.toString().trim().ifBlank { "popular videos" })
    }

    private fun saveNoteFromInput() {
        val note = input.text.toString().trim()
        if (note.isEmpty()) {
            lastCommand = ""
            reply("Type a note first, then tap Save memory.")
            return
        }
        lastCommand = ""
        notes.add(note)
        input.setText("")
        reply("Saved to this phone's local memory: $note")
    }

    // ---------------------------------------------------------------- Reply / TTS

    private fun reply(message: String, spoken: String = message) {
        output.text = if (lastCommand.isBlank()) message else "You: $lastCommand\n\nAHSAN AI: $message"
        speak(spoken)
    }

    private fun speak(message: String) {
        if (!settings.speakReplies) return
        if (!ttsReady) {
            if (!ttsWarned) {
                ttsWarned = true
                Toast.makeText(this, "Spoken replies are unavailable: no text-to-speech voice found. Replies are shown on screen.", Toast.LENGTH_LONG).show()
            }
            return
        }
        tts.setSpeechRate(settings.speechRate)
        tts.setPitch(settings.pitch)
        tts.speak(message.take(600), TextToSpeech.QUEUE_FLUSH, null, "ahsan_reply")
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            ttsReady = false
            return
        }
        var r = tts.setLanguage(Locale.getDefault())
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            r = tts.setLanguage(Locale.US)
        }
        ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                runOnUiThread { orb.state = OrbView.State.SPEAKING }
            }
            override fun onDone(utteranceId: String?) {
                runOnUiThread { orb.state = OrbView.State.IDLE }
            }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                runOnUiThread { orb.state = OrbView.State.IDLE }
            }
        })
    }

    private fun confirm(message: String, positive: String = "Yes", onYes: () -> Unit) {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("AHSAN AI")
            .setMessage(message)
            .setPositiveButton(positive) { _, _ -> onYes() }
            .setNegativeButton("Cancel") { _, _ -> reply("Okay, cancelled.") }
            .show()
    }

    // ---------------------------------------------------------------- Voice input + permission flow

    private fun startSpeech() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            launchRecognizer()
            return
        }
        if (settings.micAsked && !shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
            showMicSettingsDialog()
            return
        }
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Microphone access")
            .setMessage(
                "AHSAN AI needs the microphone so you can speak commands. " +
                    "Speech is processed by your phone's speech recognition service. " +
                    "You can still type commands if you prefer."
            )
            .setPositiveButton("Continue") { _, _ ->
                settings.micAsked = true
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), requestAudioPermission)
            }
            .setNegativeButton("Not now") { _, _ ->
                lastCommand = ""
                reply("No problem. You can type commands instead.")
            }
            .show()
    }

    private fun showMicSettingsDialog() {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Microphone is turned off")
            .setMessage("Microphone permission was denied. To use voice input, allow Microphone in the app's permission settings.")
            .setPositiveButton("Open settings") { _, _ ->
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun launchRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to AHSAN AI")
        }
        try {
            orb.state = OrbView.State.LISTENING
            startActivityForResult(intent, requestSpeech)
        } catch (e: ActivityNotFoundException) {
            orb.state = OrbView.State.IDLE
            lastCommand = ""
            reply("Speech recognition isn't available on this phone. Make sure the Google app or another voice service is installed and enabled. You can type commands instead.")
        } catch (e: Exception) {
            orb.state = OrbView.State.IDLE
            lastCommand = ""
            reply("Couldn't start voice input. You can type commands instead.")
        }
    }

    @Deprecated("Uses legacy activity result API for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestSpeech) return
        orb.state = OrbView.State.IDLE
        if (resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!words.isNullOrBlank()) {
                input.setText(words)
                handleCommand(words)
            } else {
                lastCommand = ""
                reply("I didn't catch that. Please try again.")
            }
            return
        }
        lastCommand = ""
        when (resultCode) {
            RESULT_CANCELED -> { /* user backed out; stay quiet */ }
            RecognizerIntent.RESULT_NO_MATCH -> reply("I didn't catch that. Please try again.")
            RecognizerIntent.RESULT_NETWORK_ERROR -> reply("Voice recognition needs an internet connection right now. Check your connection or type your command.")
            RecognizerIntent.RESULT_AUDIO_ERROR -> reply("There was a problem with the microphone. Please try again.")
            else -> reply("Voice recognition ran into a problem. Please try again or type your command.")
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, results)
        if (requestCode != requestAudioPermission) return
        if (results.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            launchRecognizer()
        } else if (!shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
            showMicSettingsDialog()
        } else {
            lastCommand = ""
            reply("Microphone permission is needed for voice input. You can still type commands.")
        }
    }

    // ---------------------------------------------------------------- Commands

    private fun handleCommand(raw: String) {
        val command = raw.trim()
        if (command.isEmpty()) {
            lastCommand = ""
            reply("Type or speak a command first.")
            return
        }
        lastCommand = command
        val lower = command.lowercase(Locale.ROOT)

        // Notes
        findNoteRegex.find(command)?.let { m -> return findNotes(m.groupValues[1].trim()) }
        if (lower in listOf("what do you remember", "memory", "my notes", "show notes", "show my notes", "list notes", "what are my notes")) {
            return showNotes()
        }
        if (lower in listOf("clear notes", "delete notes", "delete all notes", "clear memory", "forget everything")) {
            confirm("Delete all notes saved on this phone? This cannot be undone.", "Delete") {
                notes.clear()
                reply("All notes deleted.")
            }
            return
        }
        rememberRegex.find(command)?.let { m ->
            val note = m.groupValues[1].trim()
            notes.add(note)
            reply("Okay, saved on this phone: $note")
            return
        }

        // YouTube
        ytRegex.find(command)?.let { m ->
            val query = m.groupValues[1].replace(Regex("\\s+on\\s+youtube$", RegexOption.IGNORE_CASE), "").trim()
            openYouTube(query.ifBlank { "popular videos" })
            return
        }

        // Device commands
        if (lower.contains("wifi") || lower.contains("wi-fi")) {
            openSystemScreen(Settings.ACTION_WIFI_SETTINGS, "Wi-Fi settings", "Android doesn't let apps switch Wi-Fi on or off, so I opened the Wi-Fi settings for you.")
            return
        }
        if (lower.contains("bluetooth")) {
            openSystemScreen(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth settings", "Android doesn't let apps switch Bluetooth on or off, so I opened the Bluetooth settings for you.")
            return
        }
        if (lower == "open settings" || lower == "settings" || lower == "phone settings") {
            openSystemScreen(Settings.ACTION_SETTINGS, "Settings", "Opening your phone settings.")
            return
        }
        if (lower == "app settings" || lower == "ahsan settings" || lower == "open ahsan settings") {
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }
        if (lower.contains("flashlight") || lower.contains("torch")) {
            val turnOn = when {
                lower.contains("toggle") -> !torchOn
                lower.contains(" off") || lower.contains("turn off") || lower.contains("disable") -> false
                else -> true
            }
            setTorch(turnOn)
            return
        }
        if (lower.contains("alarm")) {
            handleAlarm(lower)
            return
        }
        if (lower.contains("battery")) {
            val level = (getSystemService(Context.BATTERY_SERVICE) as BatteryManager)
                .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            reply(if (level in 0..100) "Your battery is at $level percent." else "I couldn't read the battery level.")
            return
        }
        callRegex.find(command)?.let { m ->
            handleCall(m.groupValues[1])
            return
        }
        openRegex.find(command)?.let { m ->
            handleOpenApp(m.groupValues[1].trim())
            return
        }

        // Small talk and info
        when {
            lower == "help" || lower == "what can you do" -> reply(
                "I can: search YouTube (\"play lofi music\"), save notes (\"remember buy milk\"), " +
                    "show or search notes (\"my notes\", \"find note milk\"), open apps (\"open camera\"), " +
                    "dial a number (\"call 03001234567\"), turn the flashlight on or off, set an alarm " +
                    "(\"set alarm for 7:30 am\"), open Wi-Fi or Bluetooth settings, and tell you the time, date or battery.",
                "I can search YouTube, save notes, open apps, dial a number, control the flashlight, set alarms, and tell you the time or battery. Check the screen for examples."
            )
            lower in listOf("hello", "hi", "hey", "salam", "assalamu alaikum") -> reply("Wa alaikum assalam! How can I help?")
            lower.contains("your name") -> reply("My name is AHSAN AI, customized by Ahsan.")
            Regex("\\btime\\b").containsMatchIn(lower) ->
                reply("Your phone's current time is ${SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())}.")
            Regex("\\bdate\\b|what day").containsMatchIn(lower) ->
                reply("Today is ${SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())}.")
            else -> reply(
                "I heard: $command. I can't answer general questions yet because no online AI service is connected. Say \"help\" to see what I can do."
            )
        }
    }

    private fun showNotes() {
        val all = notes.all()
        if (all.isEmpty()) {
            reply("You haven't saved any notes yet. Say \"remember\" followed by your note.")
            return
        }
        val latest = all.takeLast(10).reversed()
        val text = latest.mapIndexed { i, n -> "${i + 1}. ${n.text}" }.joinToString("\n")
        val header = if (all.size > 10) "Your latest 10 of ${all.size} notes:" else "You have ${all.size} note(s):"
        reply("$header\n$text", "$header ${latest.joinToString(". ") { it.text }}")
    }

    private fun findNotes(query: String) {
        val hits = notes.search(query)
        if (hits.isEmpty()) {
            reply("I couldn't find a note about \"$query\".")
        } else {
            val text = hits.takeLast(10).reversed().joinToString("\n") { "• ${it.text}" }
            reply("Found ${hits.size} note(s):\n$text", "Found ${hits.size} notes. ${hits.takeLast(10).reversed().joinToString(". ") { it.text }}")
        }
    }

    private fun openYouTube(query: String) {
        val url = "https://www.youtube.com/results?search_query=" + java.net.URLEncoder.encode(query, "UTF-8")
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            reply("Opening YouTube search for $query")
        } catch (e: Exception) {
            reply("Couldn't open YouTube. Please check that a browser or the YouTube app is installed.")
        }
    }

    private fun openSystemScreen(action: String, name: String, message: String) {
        try {
            startActivity(Intent(action))
            reply(message)
        } catch (e: Exception) {
            reply("Couldn't open $name on this phone.")
        }
    }

    private fun handleOpenApp(name: String) {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val q = name.lowercase(Locale.ROOT)
        val apps = pm.queryIntentActivities(launcher, 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase(Locale.ROOT) == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase(Locale.ROOT).contains(q) }
        if (match == null) {
            reply("I couldn't find an app called \"$name\" on this phone.")
            return
        }
        val label = match.loadLabel(pm).toString()
        val pkg = match.activityInfo.packageName
        confirm("Open $label?") {
            val launch = pm.getLaunchIntentForPackage(pkg)
            if (launch == null) {
                reply("I couldn't open $label.")
            } else {
                try {
                    startActivity(launch)
                } catch (e: Exception) {
                    reply("I couldn't open $label.")
                }
            }
        }
    }

    private fun handleCall(arg: String) {
        val number = arg.filter { it.isDigit() || it == '+' }
        if (number.length < 3) {
            reply("I can open the dialer for a phone number, for example \"call 03001234567\". Calling by contact name isn't supported yet because AHSAN AI doesn't ask for contacts access.")
            return
        }
        confirm("Open the dialer with $number? You will press the call button yourself.", "Open dialer") {
            try {
                startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))
            } catch (e: Exception) {
                reply("Couldn't open the dialer on this phone.")
            }
        }
    }

    private fun setTorch(on: Boolean) {
        try {
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                reply("I couldn't find a flashlight on this phone.")
                return
            }
            cm.setTorchMode(id, on)
            torchOn = on
            reply(if (on) "Flashlight on." else "Flashlight off.")
        } catch (e: Exception) {
            reply("I couldn't change the flashlight. Another app may be using the camera.")
        }
    }

    private fun handleAlarm(lower: String) {
        val m = alarmRegex.find(lower.trim())
        if (m == null) {
            reply("Try: \"set alarm for 7:30 am\".")
            return
        }
        var hour = m.groupValues[1].toInt()
        val minute = m.groupValues[2].ifEmpty { "0" }.toInt()
        val ampm = m.groupValues[3].lowercase(Locale.ROOT)
        if (ampm == "pm" && hour < 12) hour += 12
        if (ampm == "am" && hour == 12) hour = 0
        if (hour !in 0..23 || minute !in 0..59) {
            reply("That doesn't look like a valid time. Try: \"set alarm for 7:30 am\".")
            return
        }
        val pretty = String.format(Locale.US, "%02d:%02d", hour, minute)
        confirm("Set an alarm for $pretty?", "Set alarm") {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, "AHSAN AI")
            try {
                startActivity(intent)
                reply("Alarm request sent to your clock app for $pretty.")
            } catch (e: Exception) {
                reply("I couldn't find a clock app to set the alarm.")
            }
        }
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
