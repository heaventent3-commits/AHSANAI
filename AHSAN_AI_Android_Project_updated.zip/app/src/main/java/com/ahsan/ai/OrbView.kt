package com.ahsan.ai

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min
import kotlin.math.sin

class OrbView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class State { IDLE, LISTENING, SPEAKING, THINKING }

    var state: State = State.IDLE
        set(value) {
            field = value
            invalidate()
        }

    private val density = resources.displayMetrics.density
    private val tau = (2.0 * Math.PI).toFloat()
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.rgb(55, 208, 255)
    }
    private val rect = RectF()
    private var phase = 0f

    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 3000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            phase = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!animator.isStarted) animator.start()
    }

    override fun onDetachedFromWindow() {
        animator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) * 0.26f
        val pulse = when (state) {
            State.IDLE -> sin(phase * tau) * 0.04f
            State.LISTENING -> sin(phase * tau * 2f) * 0.12f
            State.SPEAKING -> sin(phase * tau * 4f) * 0.09f
            State.THINKING -> sin(phase * tau * 3f) * 0.05f
        }
        val r = base * (1f + pulse)

        glowPaint.shader = RadialGradient(
            cx, cy, r * 2.2f,
            intArrayOf(Color.argb(120, 55, 208, 255), Color.argb(0, 55, 208, 255)),
            floatArrayOf(0.35f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r * 2.2f, glowPaint)

        corePaint.shader = RadialGradient(
            cx - r * 0.35f, cy - r * 0.35f, r * 1.5f,
            intArrayOf(Color.rgb(190, 245, 255), Color.rgb(55, 208, 255), Color.rgb(12, 70, 140)),
            floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r, corePaint)

        ringPaint.strokeWidth = 3f * density
        ringPaint.alpha = 210
        val r1 = r * 1.35f
        rect.set(cx - r1, cy - r1, cx + r1, cy + r1)
        canvas.drawArc(rect, phase * 360f, 110f, false, ringPaint)
        canvas.drawArc(rect, phase * 360f + 180f, 110f, false, ringPaint)

        ringPaint.strokeWidth = 2f * density
        ringPaint.alpha = 130
        val r2 = r * 1.65f
        rect.set(cx - r2, cy - r2, cx + r2, cy + r2)
        canvas.drawArc(rect, -phase * 720f, 70f, false, ringPaint)
        canvas.drawArc(rect, -phase * 720f + 120f, 70f, false, ringPaint)
        canvas.drawArc(rect, -phase * 720f + 240f, 70f, false, ringPaint)
    }
}
