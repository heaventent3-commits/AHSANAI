package com.ahsan.ai

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.Toast
import java.util.Locale

class SettingsActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var settings: AppSettings
    private lateinit var notes: NoteStore
    private lateinit var tts: TextToSpeech
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = AppSettings(this)
        notes = NoteStore(this)
        tts = TextToSpeech(this, this)
        buildUi()
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.navy)
            fitsSystemWindows = true
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(Ui.dp(this@SettingsActivity, 18), Ui.dp(this@SettingsActivity, 14),
                Ui.dp(this@SettingsActivity, 18), Ui.dp(this@SettingsActivity, 18))
        }
        val scroll = ScrollView(this).apply { addView(content) }
        outer.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        content.addView(Ui.label(this, "SETTINGS", 24f, Ui.cyan))
        content.addView(space(14))

        // Voice replies
        val speakSwitch = Switch(this).apply {
            text = "Speak replies aloud"
            setTextColor(Color.WHITE)
            isChecked = settings.speakReplies
            setOnCheckedChangeListener { _, checked -> settings.speakReplies = checked }
        }
        content.addView(speakSwitch)
        content.addView(space(14))

        // Speech rate: progress 0..15 -> 0.5..2.0
        content.addView(Ui.label(this, "Voice speed", 15f))
        content.addView(SeekBar(this).apply {
            max = 15
            progress = Math.round(settings.speechRate * 10f) - 5
            setOnSeekBarChangeListener(seekListener { settings.speechRate = (it + 5) / 10f })
        })
        content.addView(space(8))
        content.addView(Ui.label(this, "Voice pitch", 15f))
        content.addView(SeekBar(this).apply {
            max = 15
            progress = Math.round(settings.pitch * 10f) - 5
            setOnSeekBarChangeListener(seekListener { settings.pitch = (it + 5) / 10f })
        })
        content.addView(space(8))
        content.addView(Ui.button(this, "Test voice") { testVoice() }, buttonParams())

        // Notes
        content.addView(space(18))
        content.addView(Ui.label(this, "Local notes", 18f, Ui.cyan))
        content.addView(Ui.label(this, "${notes.all().size} note(s) saved on this phone only.", 14f, Color.LTGRAY))
        content.addView(Ui.button(this, "Clear all notes") { confirmClearNotes() }, buttonParams())

        // Permissions
        content.addView(space(18))
        content.addView(Ui.label(this, "Permissions", 18f, Ui.cyan))
        val micGranted = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        content.addView(Ui.label(this, "Microphone: " + if (micGranted) "allowed" else "not allowed", 14f, Color.LTGRAY))
        content.addView(Ui.button(this, "Open app permission settings") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null)))
        }, buttonParams())

        // About
        content.addView(space(18))
        content.addView(Ui.label(this, "About", 18f, Ui.cyan))
        content.addView(Ui.label(
            this,
            "AHSAN AI 1.1\nCustomized by Ahsan\n\n" +
                "Voice input uses your phone's speech recognition service. " +
                "No online AI model is connected, so general questions can't be answered yet.",
            14f, Color.LTGRAY
        ))

        content.addView(space(18))
        content.addView(Ui.button(this, "Back") { finish() }, buttonParams())
        setContentView(outer)
    }

    private fun seekListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange(progress)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private fun space(heightDp: Int) = android.view.View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, Ui.dp(this@SettingsActivity, heightDp))
    }

    private fun buttonParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 50)
    ).apply { topMargin = Ui.dp(this@SettingsActivity, 8) }

    private fun testVoice() {
        if (!ttsReady) {
            Toast.makeText(this, "No text-to-speech voice is available on this phone.", Toast.LENGTH_LONG).show()
            return
        }
        tts.setSpeechRate(settings.speechRate)
        tts.setPitch(settings.pitch)
        tts.speak("Hello, I am AHSAN AI, customized by Ahsan.", TextToSpeech.QUEUE_FLUSH, null, "ahsan_test")
    }

    private fun confirmClearNotes() {
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Clear all notes?")
            .setMessage("This permanently deletes every note saved by AHSAN AI on this phone.")
            .setPositiveButton("Delete") { _, _ ->
                notes.clear()
                buildUi()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        var r = tts.setLanguage(Locale.getDefault())
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            r = tts.setLanguage(Locale.US)
        }
        ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
    }

    override fun onDestroy() {
        tts.stop()
        tts.shutdown()
        super.onDestroy()
    }
}
